<header>
	<div id="logo">
		<figure> <a href="https://www.u-cergy.fr/fr/index.html"><img src="../Images/logo-ucp.png" alt="Logo UCP"></a>
		<figcaption>Partenaire</figcaption>		
		</figure>
	</div>
	
	<nav id="princ">
	<ul>
		<li><a href="../index.html">Accueil</a></li>
		<li><a href="../TD5/index.php">TD 5</a></li>
		<li><a href="../TD6/index.php">TD 6</a></li>
		<li><a href="../TD7/index.php">TD 7</a></li>
		<li><a href="../TD8/index.php">TD 8</a></li>
		<li><a href="../TD9/index.php">TD 9</a></li>
		<li id="encours"><a href="index.php">TD 10</a></li>
		<li><a href="../TD11/index.php">TD 11</a></li>
		<li><a href="../TD12/index.php">TD 12</a></li>
		<li><a href="../contact.html" >Contact</a></li>
	</ul>
	</nav>
	
</header>